# CoreApiFundamentals
Before start, run "dotnet ef database update" first
