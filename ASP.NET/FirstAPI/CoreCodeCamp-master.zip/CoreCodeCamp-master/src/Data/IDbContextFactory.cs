﻿namespace CoreCodeCamp.Data
{
    public interface IDbContextFactory
    {
    }
}